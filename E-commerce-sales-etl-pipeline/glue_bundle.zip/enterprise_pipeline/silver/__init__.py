"""Silver layer package."""
