from enterprise_pipeline.bronze.bronze_runner import main


if __name__ == "__main__":
    raise SystemExit(main())
